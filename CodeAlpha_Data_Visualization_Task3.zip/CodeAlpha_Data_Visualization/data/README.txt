Educational sales dataset for CodeAlpha Task 3. Revenue is derived from units_sold, unit_price_inr and discount_rate.

# CodeAlpha Task 3 – Data Visualization

## Project: Sales Performance Data Visualization

This project transforms raw sales data into clear visual formats using Python and Matplotlib. It is designed to satisfy CodeAlpha Internship **Task 3: Data Visualization**.

### Objectives
- Transform raw data into charts and graphs.
- Design visuals that make patterns and comparisons easy to understand.
- Create a data story that supports business decision-making.
- Build a portfolio-ready visualization project.

### Tools
- Python
- Pandas
- Matplotlib
- Jupyter Notebook

### Dataset
The project uses a small sales dataset containing:
- Month
- Region
- Category
- Product
- Units sold
- Unit price
- Discount rate
- Revenue

Revenue is calculated as:

`Units Sold × Unit Price × (1 − Discount Rate)`

### Visualizations
1. Monthly Revenue Trend – shows changes in revenue over time.
2. Revenue by Category – compares category performance.
3. Revenue by Region – identifies strong-performing regions.
4. Units Sold by Product – shows product demand mix.

### Data Story
The visuals are designed to answer practical business questions:
- Which months perform better?
- Which categories generate more revenue?
- Which regions contribute most?
- Which products have the strongest unit demand?

### Key Insights
The analysis script prints the highest-revenue category, highest-revenue region, best-selling product, and total revenue. These insights can support inventory planning, regional strategy, and product prioritization.

### How to run
```bash
pip install -r requirements.txt
python src/visualization.py
```

To explore interactively:
```bash
jupyter notebook notebooks/Data_Visualization_analysis.ipynb
```

### CodeAlpha Task 3 Mapping
- Transform raw data → Pandas data transformation.
- Charts/graphs → Matplotlib.
- Clear visual design → four focused charts with titles and labels.
- Data storytelling → business questions and decision-oriented insights.
- Portfolio building → clean GitHub structure with source code, dataset, notebook, and output visuals.

### Ethical / project note
The dataset is a small educational sample created for internship demonstration and visualization practice. It should not be presented as real company sales data.

import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "sales_visualization_dataset.csv"
OUT = ROOT / "outputs"
OUT.mkdir(exist_ok=True)

df = pd.read_csv(DATA)

# Transform raw data
df["revenue_inr"] = df["units_sold"] * df["unit_price_inr"] * (1 - df["discount_rate"])

monthly = df.groupby("month", as_index=False)["revenue_inr"].sum()
category = df.groupby("category", as_index=False)["revenue_inr"].sum().sort_values("revenue_inr", ascending=False)
region = df.groupby("region", as_index=False)["revenue_inr"].sum().sort_values("revenue_inr", ascending=False)
product = df.groupby("product", as_index=False)["units_sold"].sum().sort_values("units_sold", ascending=False)

# 1. Trend chart
plt.figure(figsize=(9, 5))
plt.plot(monthly["month"], monthly["revenue_inr"], marker="o")
plt.title("Monthly Revenue Trend")
plt.xlabel("Month")
plt.ylabel("Revenue (INR)")
plt.xticks(rotation=30)
plt.tight_layout()
plt.savefig(OUT / "monthly_revenue_trend.png", dpi=160)
plt.close()

# 2. Category comparison
plt.figure(figsize=(9, 5))
plt.bar(category["category"], category["revenue_inr"])
plt.title("Revenue by Category")
plt.xlabel("Category")
plt.ylabel("Revenue (INR)")
plt.xticks(rotation=20)
plt.tight_layout()
plt.savefig(OUT / "revenue_by_category.png", dpi=160)
plt.close()

# 3. Regional performance
plt.figure(figsize=(9, 5))
plt.barh(region["region"], region["revenue_inr"])
plt.title("Revenue by Region")
plt.xlabel("Revenue (INR)")
plt.ylabel("Region")
plt.tight_layout()
plt.savefig(OUT / "revenue_by_region.png", dpi=160)
plt.close()

# 4. Product mix
plt.figure(figsize=(9, 5))
plt.pie(product["units_sold"], labels=product["product"], autopct="%1.1f%%")
plt.title("Units Sold by Product")
plt.tight_layout()
plt.savefig(OUT / "units_by_product.png", dpi=160)
plt.close()

print("Visualization project completed.")
print("\nKey insights:")
print(f"Highest-revenue category: {category.iloc[0]['category']}")
print(f"Highest-revenue region: {region.iloc[0]['region']}")
print(f"Best-selling product by units: {product.iloc[0]['product']}")
print(f"Total revenue: ₹{df['revenue_inr'].sum():,.2f}")
